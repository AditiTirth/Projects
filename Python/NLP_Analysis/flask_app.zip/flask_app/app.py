from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

# Load the model and vectorizer
with open('lightgbm_model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

with open('tfidf_vectorizer.pkl', 'rb') as vectorizer_file:
    vectorizer = pickle.load(vectorizer_file)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get the comment from the form
    comment = request.form['text']
    
    # Transform the comment using the vectorizer
    comment_transformed = vectorizer.transform([comment])
    
    # Make a prediction
    prediction = model.predict(comment_transformed)[0]
    
    # Convert the prediction to a readable format
    sentiment = "Positive" if prediction == 1 else "Negative"
    
    # Pass both the comment and the prediction back to the template
    return render_template('index.html', prediction=sentiment, comment=comment)

if __name__ == "__main__":
    app.run(debug=True)
